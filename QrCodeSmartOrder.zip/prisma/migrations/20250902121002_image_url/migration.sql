-- AlterTable
ALTER TABLE `Product` ADD COLUMN `imageUrl` VARCHAR(191) NULL;
