export interface CartItemType {
  productId: number;
  name: string;
  price: number;
  quantity: number;
}
